<rn:meta controller_path="custom/output/MeterHistory" js_path="custom/output/MeterHistory" presentation_css="widgetCss/Grid2.css" base_css="custom/output/MeterHistory"/>
<div id="rn_div_meterHistory_<?=$this->instanceID;?>"></div>
