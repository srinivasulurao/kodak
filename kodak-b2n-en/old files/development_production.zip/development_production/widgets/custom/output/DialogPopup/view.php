<rn:meta controller_path="custom/output/DialogPopup" js_path="custom/output/DialogPopup" base_css="custom/output/DialogPopup"/>

<!-- Source file -->
<?
$this->addJavaScriptInclude(getYUICodePath('container/container-min.js"></script>'));
?>





 
