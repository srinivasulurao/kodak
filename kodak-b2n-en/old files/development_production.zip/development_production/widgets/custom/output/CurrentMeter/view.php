<rn:meta controller_path="custom/output/CurrentMeter" js_path="custom/output/CurrentMeter" presentation_css="widgetCss/Grid2.css" base_css="custom/output/CurrentMeter"/>
<div id="meter_err_<?=$this->instanceID;?>" class="meter_error"></div>
<div id="meter_success_<?=$this->instanceID;?>" class="meter_error"></div>
<div id="rn_div_currentMeter_<?=$this->instanceID;?>"></div>
