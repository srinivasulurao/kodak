<rn:meta controller_path="custom/output/WaitingPanel" js_path="custom/output/WaitingPanel" presentation_css="widgetCss/Grid2.css" base_css="custom/output/WaitingPanel"/>

<!-- Source file -->
<?
$this->addJavaScriptInclude(getYUICodePath('container/container-min.js"></script>'));
?>







 
