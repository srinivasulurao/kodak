<rn:meta controller_path="custom/sample/SampleWidget" js_path="custom/sample/SampleWidget" base_css="custom/sample/SampleWidget" presentation_css="widgetCss/SampleWidget.css"/>

<!-- Add HTML/PHP view code here -->

