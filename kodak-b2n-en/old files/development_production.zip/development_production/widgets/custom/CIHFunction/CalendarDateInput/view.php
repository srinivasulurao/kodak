<rn:meta controller_path="custom/CIHFunction/CalendarDateInput"  js_path="custom/CIHFunction/CalendarDateInput"  base_css="custom/CIHFunction/CalendarDateInput" presentation_css="widgetCss/CalendarDateInput.css"/>

<link rel="stylesheet" type="text/css" href="/euf/assets/css/yui/calendar.css" />

<? $this->addJavaScriptInclude(getYUICodePath('calendar/calendar-min.js'));?>

<input type="text" name="cal1Date" id="cal1Date" autocomplete="off"/>  
<div id="cal1Container"></div>

