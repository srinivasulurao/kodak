<rn:meta controller_path="custom/CIHFunction/ServiceRequestDetailsData" presentation_css="widgetCss/SampleWidget.css"/>
