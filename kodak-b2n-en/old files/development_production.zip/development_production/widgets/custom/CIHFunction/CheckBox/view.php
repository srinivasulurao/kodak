<rn:meta controller_path="custom/CIHFunction/CheckBox" js_path="custom/CIHFunction/CheckBox" presentation_css="widgetCss/CheckBox.css"  />

<input type="checkbox" id="rn_<?=$this->instanceID?>_CheckBox" <?=$this->data['attrs']['checked']== true ? 'checked="checked"':'' ?> name="<?=$this->data['attrs']['name']?>" value="<?=$this->data['attrs']['value']?>" />

