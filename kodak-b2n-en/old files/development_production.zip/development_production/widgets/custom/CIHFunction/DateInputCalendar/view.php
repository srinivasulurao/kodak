<rn:meta controller_path="custom/CIHFunction/DateInputCalendar"  js_path="custom/CIHFunction/DateInputCalendar"  base_css="custom/CIHFunction/DateInputCalendar" presentation_css="widgetCss/DateInputCalendar.css"/>
<!---->
<link rel="stylesheet" type="text/css" href="/euf/assets/css/yui/calendar.css" />

<? $this->addJavaScriptInclude(getYUICodePath('calendar/calendar-min.js'));?>

<input type="text" name="cal1Date" id="cal1Date" autocomplete="off"/>&nbsp;-to-&nbsp;<input type="text" name="cal2Date" id="cal2Date" autocomplete="off"/>  
<div id="cal1Container"></div>

