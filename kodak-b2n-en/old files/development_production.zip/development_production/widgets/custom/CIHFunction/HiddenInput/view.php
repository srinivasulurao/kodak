<rn:meta controller_path="custom/CIHFunction/HiddenInput" js_path="custom/CIHFunction/HiddenInput" />

<!-- HiddenInput is hiding! -->

<div class="rn_Hidden">
    <input id="rn_<?=$this->instanceID?>_HiddenInput" name="<?=$this->data['attrs']['name']?>" value="<?=$this->data['attrs']['value']?>" />
</div>
