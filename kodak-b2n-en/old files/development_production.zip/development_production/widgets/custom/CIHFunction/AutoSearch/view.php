<rn:meta controller_path="custom/CIHFunction/AutoSearch" js_path="custom/CIHFunction/AutoSearch" base_css="custom/sample/SampleWidget" presentation_css="widgetCss/SampleWidget.css"/>

