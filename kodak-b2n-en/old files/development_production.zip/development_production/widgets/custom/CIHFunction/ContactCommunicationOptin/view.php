<rn:meta controller_path="custom/CIHFunction/ContactCommunicationOptin" js_path="custom/CIHFunction/ContactCommunicationOptin" presentation_css="widgetCss/ContactSelect.css" compatibility_set="November '09+"/>
<div id="rn_<?=$this->instanceID;?>_communicationPref" style="display:none" >
<h2>Partner Communication Preferences</h2>
<!-- Panel content goes here -->
<div id="rn_<?=$this->instanceID;?>_div_optintable"></div>
</div>
