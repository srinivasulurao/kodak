<rn:meta title="#rn:msg:PAGE_NOT_FOUND_LBL#" template="mobile.php" login_required="false"/>

<div id="rn_PageTitle" class="rn_ErrorPage">
    <h1>#rn:msg:PAGE_NOT_FOUND_LBL#</h1>
</div>

<div id="rn_PageContent" class="rn_ErrorPage">
    <div class="rn_Padding">
        <p>#rn:msg:PAGE_YOU_REQUESTED_WAS_NOT_FOUND_MSG#</p>
    </div>
</div>