<rn:meta title="#rn:msg:POST_LBL#" template="mobile.php" clickstream="post_view"/>
<div class="section rn_PostDetail">
    <rn:widget path="standard/social/CommunityPostDisplay"/>
</div>
