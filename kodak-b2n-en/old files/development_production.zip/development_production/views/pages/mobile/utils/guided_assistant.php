<rn:meta title="#rn:msg:GUIDED_HELP_LBL#" template="mobile.php"/>

<section id="rn_PageContent" class="rn_StandAloneGuide">
    <rn:widget path="knowledgebase/GuidedAssistant" single_question_display="true" label_question_back="#rn:msg:GO_BACK_CMD#" label_text_result=""/>
</section>
