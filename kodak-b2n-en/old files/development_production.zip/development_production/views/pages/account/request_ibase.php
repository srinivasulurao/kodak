<rn:meta title="#rn:msg:ACCOUNT_SETTINGS_LBL#" template="kodak_b2b_template.php" login_required="true" />
<div id="rn_PageContent" class="rn_Profile">
<rn:widget path="custom/output/WaitingPanel" />
</div>
