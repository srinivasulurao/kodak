<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="redirectkodak_b2b_template.php" clickstream="home"/>
<div id="rn_PageTitle" class="rn_Home">
