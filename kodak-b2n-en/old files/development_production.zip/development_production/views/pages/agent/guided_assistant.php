<rn:meta title="#rn:msg:GUIDED_ASSISTANT_LBL#" template="agent.php" account_session_required="true"/>
<rn:widget path="knowledgebase/GuidedAssistant"/>
