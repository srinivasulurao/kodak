<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="kodak_b2b_template_fullwidth.php" clickstream="home"/>

<div id="rn_PageTitle" class="rn_Home">
    <h1>Service My Products</h1>
<a href="https://services.kodak.com/app/answers/detail/a_id/66890" target="_blank">View Help</a>
</div>
<div id="rn_PageContent" class="rn_Home">
     <rn:widget path="custom/CIHSearch/SearchTabSet" />
</div>
