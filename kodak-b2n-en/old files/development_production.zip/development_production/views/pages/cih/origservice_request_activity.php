<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="kodak_b2b_template_fullwidth.php" clickstream="contact_create" login_required="true"/>
<div id="rn_PageTitle" class="rn_AskQuestion">
    <h1>Service Request Activity</h1>
<a href="https://services.kodak.com/app/answers/detail/a_id/66890" target="_blank">View Help</a>
</div>
<br/>
<div id="rn_PageContent" class="rn_QuestionDetail">
    <div class="rn_Padding">
		<rn:widget path="custom/CIHFunction/ServiceRequestActivity" report_id="100902" />
		<rn:widget path="custom/CIHFunction/ServiceRequestActivityHydrateFields" report_id="100902" />	
	</div>
</div>

