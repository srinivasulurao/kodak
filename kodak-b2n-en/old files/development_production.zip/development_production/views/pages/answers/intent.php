<rn:meta title="#rn:msg:ANSWER_LBL#" template="standard.php" clickstream="intentguide_view" />

<div id="rn_PageContent" class="rn_AnswerDetail">
    <div class="rn_Padding">        
        <rn:widget path="knowledgebase/IntentGuideDisplay"/>
        <div id="rn_DetailTools">
            <rn:widget path="utils/SocialBookmarkLink" />
            <rn:widget path="utils/PrintPageLink" />
        </div>
    </div>
</div>
