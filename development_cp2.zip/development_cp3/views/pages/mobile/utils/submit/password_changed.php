<rn:meta title="#rn:msg:PASSWORD_CHANGE_SUCCEEDED_LBL#" template="mobile.php" login_required="true"/>

<div id="rn_PageTitle">
    <h1>#rn:msg:THANK_YOU_LBL#</h1>
</div>
<div id="rn_PageContent">
    <div class="rn_Padding">
        #rn:msg:YOUR_PASSWORD_HAS_BEEN_CHANGED_MSG#
    </div>
</div>
