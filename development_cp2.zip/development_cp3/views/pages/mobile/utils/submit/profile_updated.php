<rn:meta title="#rn:msg:PROFILE_UPD_SUCCEED_HDG#" template="mobile.php" login_required="true"/>

<div id="rn_PageTitle">
    <h1>#rn:msg:THANK_YOU_LBL#</h1>
</div>
<div id="rn_PageContent">
    <div class="rn_Padding">
        #rn:msg:WEVE_UPDATED_ACCOUNT_INFORMATION_MSG#
    </div>
</div>
