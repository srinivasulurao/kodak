<rn:meta title="#rn:msg:RESET_PASSWORD_CMD#" template="mobile.php" login_required="false" />
<? /*This page is navigated to by following an email link when:
user or agent triggers 'reset password' routine */?>
<section id="rn_PageTitle" class="rn_Account">
    <h1>#rn:msg:RESET_YOUR_PASSWORD_CMD#</h1>
</section>
<section id="rn_PageContent">
    <div class="rn_Padding">
        <rn:widget path="login/ResetPassword2" />
    </div>
</section>
