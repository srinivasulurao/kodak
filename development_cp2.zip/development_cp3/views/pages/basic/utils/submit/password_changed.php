<rn:meta title="#rn:msg:PASSWORD_CHANGE_SUCCEEDED_LBL#" template="basic.php" login_required="true" />

<p><b>#rn:msg:THANK_YOU_LBL#</b></p>
<p>#rn:msg:YOUR_PASSWORD_HAS_BEEN_CHANGED_MSG#</p>
