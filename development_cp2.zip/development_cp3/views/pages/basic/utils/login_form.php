<rn:meta title="#rn:msg:SUPPORT_LOGIN_HDG#" template="basic.php" redirect_if_logged_in="account/overview" force_https="true"/>

<rn:widget path="login/BasicLoginForm"/>
<p>
    <a href="/app/#rn:config:CP_ACCOUNT_ASSIST_URL##rn:session#">#rn:msg:FORGOT_YOUR_USERNAME_OR_PASSWORD_MSG#</a>
</p>
