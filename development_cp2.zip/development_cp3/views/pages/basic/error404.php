<rn:meta title="#rn:msg:PAGE_NOT_FOUND_LBL#" template="basic.php" login_required="false"/>
<h1>#rn:msg:PAGE_NOT_FOUND_LBL#</h1>
<p>#rn:msg:PAGE_YOU_REQUESTED_WAS_NOT_FOUND_MSG#</p>
