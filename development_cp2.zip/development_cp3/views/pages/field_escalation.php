<rn:meta title="Field Escalation" template="kodak_b2b_template.php" />
<div id="rn_PageTitle" class="rn_AskQuestion">
    <h1><? echo $templ_msg_base_array['lbl_field_escalation']; ?></h1>
</div>
<div id="rn_PageContent" >
    <div class="rn_Padding"><? echo $templ_msg_base_array['lbl_esc_tab_intro']; ?>
	</div>
	
</div>
