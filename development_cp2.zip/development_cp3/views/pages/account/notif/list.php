<rn:meta title="#rn:msg:NOTIFICATIONS_HDG#" template="kodak_b2b_template.php" login_required="true"/>
<div id="rn_PageTitle" class="rn_Account">
    <h1>#rn:msg:NOTIFICATIONS_HDG#</h1>
</div>
<div id="rn_PageContent">
    <div class="rn_Padding">
        <h2>#rn:msg:NOTIFICATIONS_HDG#</h2>
        <rn:widget path="notifications/AnswerNotificationManager" />
        <h2><? echo $templ_msg_base_array['lbl_answer_notify_product_category']; ?></h2>
        <rn:widget path="notifications/ProdCatNotificationManager" />
    </div>
</div>
