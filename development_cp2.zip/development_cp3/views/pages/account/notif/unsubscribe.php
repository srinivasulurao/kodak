<rn:meta title="#rn:msg:YOUR_NOTIFICATION_REQUESTS_LBL#" template="kodak_b2b_template.php" />
<div id="rn_PageTitle" class="rn_Account">
    <h1>#rn:msg:NOTIFICATIONS_HDG#</h1>
</div>
<div id="rn_PageContent" class="rn_Account">
    <div class="rn_Padding">
        <rn:widget path="notifications/Unsubscribe2"/>
    </div>
</div>
