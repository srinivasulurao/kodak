<rn:meta title="#rn:msg:RESET_PASSWORD_CMD#" template="kodak_b2b_template_nologin.php" />
<!-- This page is navigated to by following an email link when:
user or agent triggers 'reset password' routine-->
<div id="rn_PageTitle" class="rn_Account">
    <h1>#rn:msg:RESET_YOUR_PASSWORD_CMD#</h1>
</div>
<div id="rn_PageContent">
    <div class="rn_Padding">
        <rn:widget path="login/ResetPassword2" />
    </div>
</div>
