<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

function helperFunction()
{
    //This helper would be loaded by using $this->load->helper('sample') or by
    //using $this->CI->load->helper('sample') in a widget controller. Once loaded
    //you can use this function by simply using helperFunction()
}
