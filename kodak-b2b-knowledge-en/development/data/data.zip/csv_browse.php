"variable_name","kodak_b2b_en","kodak_b2b_knowledge_en/English (US)","kodak_b2b_knowledge_ja","kodak_b2b_ja","kodak_b2b_aga_en","kodak_b2b_founder_en","kodak_b2b_presstek_en"
"browse_by_lbl","<br/>","<br/>","<br/>","<br/>","<br/>","<br/>","<br/>"
"product_lbl","Filter by Product","Filter by Product","プロダクトを選択","プロダクトを選択","Filter by Product","Filter by Product","Filter by Product"
"category_lbl","Filter by Category","Filter by Category","カテゴリを選択","カテゴリを選択","Filter by Category","Filter by Category","Filter by Category"
