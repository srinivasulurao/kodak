"variable_name","kodak_b2b_en","kodak_b2b_knowledge_en/English (US)","kodak_b2b_knowledge_ja","kodak_b2b_ja","kodak_b2b_aga_en","kodak_b2b_founder_en","kodak_b2b_presstek_en"
"morefieldslabel",," Troubleshooting details (optional) ","トラブルシューティングの詳細を追加（任意）",,,,
