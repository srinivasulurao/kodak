"variable_name","kodak_b2b_en","kodak_b2b_knowledge_en/English (US)","kodak_b2b_knowledge_ja","kodak_b2b_ja","kodak_b2b_aga_en","kodak_b2b_founder_en","kodak_b2b_presstek_en"
"whatsnewreport_id",100146,100145,100154,100155,100215,100277,100246
"whatsnew","What's New?","What's New?","最新情報","最新情報","What's New?","What's New?","What's New?"
"mostpopularreport_id",100308,100309,100306,100307,100303,100304,100305
"welcomemessage",,,,,,,
"filterlistby","Filter List By : &nbsp;","Filter List By : &nbsp;","目的の項目を選択&nbsp;","目的の項目を選択&nbsp;","Filter List By : &nbsp;","Filter List By : &nbsp;","Filter List By : &nbsp;"
